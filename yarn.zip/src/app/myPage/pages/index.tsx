import React from "react";
import UserProfile from "../_components/UserProfile";

const myPage = () => {
  return (
    <div>
      <UserProfile />
    </div>
  );
};

export default myPage;
