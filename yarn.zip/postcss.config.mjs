const config = {
  plugins: {
    tailwindcss: {},

  },
};

export default config;
